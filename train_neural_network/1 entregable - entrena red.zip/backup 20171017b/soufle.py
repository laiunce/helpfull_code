#!/Users/laiunce/anaconda/bin/python
# -*- coding: utf-8 -*-
"""
Created on Sat Sep 30 11:46:45 2017

@author: laiunce
"""
import csv
import numpy as np
import pandas as pd

directorio ='/Users/laiunce/Desktop/Entrena_red/'
dataframe = np.load(directorio+'dataframe.npy')

np.random.shuffle(dataframe)

np.save(directorio+'soufle.npy', dataframe)



